package com.example.menshanalla.Model

data class Service(
    val description: String = "",
    val imageUri: String = "",
    val price: String = ""

)
