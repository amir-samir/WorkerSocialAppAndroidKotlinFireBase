package com.example.menshanalla.Model

data class EditServicesData(
    val uid: String? = null,
    val theService: Service? = null
)
