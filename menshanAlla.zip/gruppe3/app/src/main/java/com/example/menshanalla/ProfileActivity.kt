package com.example.handwerkeryarab

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.ActionBar
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.example.menshanalla.R
import com.example.menshanalla.databinding.ActivityProfileBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*

class ProfileActivity : AppCompatActivity() {
    //ViewBinding
    private lateinit var binding: ActivityProfileBinding

    //ActionBar
    private lateinit var actionBar: ActionBar

    //FirebaseAuth
    private lateinit var firebaseAuth: FirebaseAuth

    //FirebaseDataBase
    private lateinit var databaseReference: DatabaseReference

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityProfileBinding.inflate(layoutInflater)
        setContentView(binding.root)

        //Configure ActionBar
        actionBar = supportActionBar!!
        actionBar.title = "Profile"

        //init firebase auth
        firebaseAuth = FirebaseAuth.getInstance()
        //val uid = firebaseAuth.currentUser?.uid
        //databaseReference = FirebaseDatabase.getInstance().getReference("User")

        checkUser()
        loadUserInfo()

        // go back button
        binding.backBtn.setOnClickListener {
            onBackPressed()
        }

        //handle click, logout
        binding.logoutBtn.setOnClickListener {
            firebaseAuth.signOut()
            checkUser()
        }

        //handle edit Button
        binding.profileEditBtn.setOnClickListener {
            startActivity(Intent(this, ProfileEditActivity::class.java))
        }


    }
////
    private fun loadUserInfo() {
        //db reference to load user info
        val ref = FirebaseDatabase.getInstance().getReference("Workers")
        ref.child(firebaseAuth.uid!!)
            .addValueEventListener(object: ValueEventListener{
                override fun onDataChange(snapshot: DataSnapshot) {
                    //get user info if they are not equal to null
                    val job = "${snapshot.child("workerJob").value}"
                    val fullName = "${snapshot.child("workerName").value}"
                    val profileImage = "${snapshot.child("profileImage").value}"
                    val uid = "${snapshot.child("workerId").value}"
                    val userType = "${snapshot.child("userType").value}"
                    val workPlaces = "${snapshot.child("workerPlaces").value}"
                    //val latitude = "${snapshot.child("longtitude").value}"

                    //set data
                    binding.nameTv.text = fullName
                    binding.jobTv.text = job
                    binding.userTypeTv.text = userType
                    binding.workPlacesTv.text = workPlaces

                    //set image
                    try{
                        Glide.with(this@ProfileActivity)
                            .load(profileImage)
                            .placeholder(R.drawable.ic_person_gray)
                            .into(binding.profileTv)

                    }
                    catch (e: Exception){

                    }
                }

                override fun onCancelled(error: DatabaseError) {
                    TODO("Not yet implemented")
                }

            } )
    }

    private fun checkUser() {
        //check if user is logged in
        val firebaseUser = firebaseAuth.currentUser
        if (firebaseUser != null){
            //user not null, user is logged in
            //get user info
            val email = firebaseUser.email
            //set to text View
            binding.emailTv.text = email
        }
        else{
            //user is null, user is not loggedin -> return to Login
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
        }
    }
}