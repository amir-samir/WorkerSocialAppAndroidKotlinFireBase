package com.example.menshanalla

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import com.google.android.material.bottomnavigation.BottomNavigationView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.navigation.findNavController
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.setupActionBarWithNavController
import androidx.navigation.ui.setupWithNavController
import com.bumptech.glide.Glide
import com.example.handwerkeryarab.ProfileActivity
import com.example.handwerkeryarab.ProfileEditActivity
import com.example.menshanalla.databinding.ActivityMainBinding
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.libraries.places.api.Places
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class MainActivity : AppCompatActivity() {



    //FirebaseAuth
    private var editBackPressed: String = ""
    var loadProfile = false
    private lateinit var firebaseAuth: FirebaseAuth
    private lateinit var binding: ActivityMainBinding

    private val onNavigationItemSelectedListener = BottomNavigationView.OnNavigationItemSelectedListener { item ->
        when (item.itemId) {
            R.id.nav_home -> {
                changeFragment(homeFragment())
                return@OnNavigationItemSelectedListener true
            }
            R.id.nav_search -> {
                /*changeFragment(SearchFragment())
                return@OnNavigationItemSelectedListener true*/
                startActivity(Intent(this, EditService::class.java))
            }
            R.id.nav_kalendar -> {
                startActivity(Intent(this, ServiceActivity::class.java))
            }
            R.id.nav_chat -> {
                changeFragment(ChatFragment())
                return@OnNavigationItemSelectedListener true
            }
            R.id.nav_profile -> {
                changeFragment(ProfileFragment())
                return@OnNavigationItemSelectedListener true
            }
        }


        false
    }



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //editBackPressed = "false"
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        val navView: BottomNavigationView = binding.navView
        firebaseAuth = FirebaseAuth.getInstance()
        changeFragment(homeFragment())
        binding.addPostButton.setOnClickListener {
            startActivity(Intent(this, PostsActivity::class.java))
        }

        //checkPermission()
        //loadUserInfo()



        navView.setOnNavigationItemSelectedListener(onNavigationItemSelectedListener)
    }

    fun changeFragment(fragment: Fragment){
        val fragmentChange = supportFragmentManager.beginTransaction()
        fragmentChange.replace(R.id.fragment_container, fragment)
        fragmentChange.commit()
    }

    //private fun checkPermission(){
    //    if(ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)!= PackageManager.PERMISSION_GRANTED) {
    //        ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 1)
    //        return
    //    }
    //}

    private fun loadUserInfo() {
        //db reference to load user info
        val ref = FirebaseDatabase.getInstance().getReference("Workers")
          ref.child(firebaseAuth.uid!!)
            .addValueEventListener(object: ValueEventListener {
                override fun onDataChange(snapshot: DataSnapshot) {
                    //get user info if they are not equal to null
                  if("${snapshot.child("backFromEditProfilePressed").value}".equals("true")){
                      supportFragmentManager.beginTransaction().replace(R.id.fragment_container, ProfileFragment())
                      .commit()
                  }

                    val hashmap: HashMap<String, Any> = HashMap()
                    hashmap["backFromEditProfilePressed"] = "false"

                    val reference = FirebaseDatabase.getInstance().getReference("Workers")
                    reference.child(firebaseAuth.uid!!)
                        .updateChildren(hashmap)

                }

                override fun onCancelled(error: DatabaseError) {
                    TODO("Not yet implemented")
                }
            })
    }

    private fun changeValueOfProfileBackPressed() {
        val hashmap: HashMap<String, Any> = HashMap()
        hashmap["backFromEditProfilePressed"] = "false"

        val reference = FirebaseDatabase.getInstance().getReference("Workers")
        reference.child(firebaseAuth.uid!!)
            .updateChildren(hashmap)
            .addOnSuccessListener {
                //profile updated
                Toast.makeText(this, "worked", Toast.LENGTH_SHORT).show()
            }
            .addOnFailureListener {e->
                //failed to update profile
                Toast.makeText(this, "Failed to update Profile due to ${e.message}", Toast.LENGTH_SHORT).show()

            }
    }
}