package com.example.menshanalla.Model

data class FollowingPosting(
    val uid: String? = null,
    val thePosts: MutableList<Posts>? = null

)
