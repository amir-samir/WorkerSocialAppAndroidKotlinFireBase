package com.example.menshanalla.Model

data class ProjectAndId(
    val uid: String? = null,
    val theProject: PrjectData? = null
)
