package com.example.menshanalla.Model

data class PostAndId(
    val uid: String? = null,
    val thePosts: Posts? = null
)
