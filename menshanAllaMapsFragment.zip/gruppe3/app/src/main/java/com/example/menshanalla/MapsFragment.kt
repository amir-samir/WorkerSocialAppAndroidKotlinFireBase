package com.example.menshanalla

//import com.example.menshanalla.databinding.ActivityProfileBinding

import android.Manifest
import android.content.ContentValues.TAG
import android.content.Intent
import android.content.pm.PackageManager
import android.location.*
import android.nfc.Tag
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import com.example.handwerkeryarab.ProfileEditActivity
import com.example.menshanalla.databinding.FragmentMapsBinding
import com.google.android.gms.common.ConnectionResult
import com.google.android.gms.common.api.GoogleApiClient
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationServices
import com.google.android.gms.maps.*
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.Marker
import com.google.android.gms.maps.model.MarkerOptions
import com.google.android.libraries.places.api.Places
import com.google.android.libraries.places.api.net.PlacesClient
import com.google.android.libraries.places.widget.AutocompleteSupportFragment
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.FirebaseDatabase
import kotlinx.android.synthetic.main.fragment_maps.*
import java.util.*


private lateinit var googleMap: GoogleMap
private lateinit var lastLocation: Location
private lateinit var binding: FragmentMapsBinding
private lateinit var fusedLocationProviderClient : FusedLocationProviderClient
private lateinit var currentLat: Number
private lateinit var currentLong : Number
private lateinit var currentLatLong: LatLng
private lateinit var firebaseAuth: FirebaseAuth
private lateinit var locationListener: LocationListener

private lateinit var geocoder : Geocoder
private lateinit var myadresses: List<Address>
private lateinit var address: Address
private lateinit var googleApiClient: GoogleApiClient
private lateinit var mLocationRequest: LocationRequest

private lateinit var searchView: SearchView
private lateinit var markerOptions: MarkerOptions
private lateinit var mCurrLocationMarker: Marker
private lateinit var placesClient: PlacesClient
private lateinit var autoCompleteFrgment: AutocompleteSupportFragment
private lateinit var locationCallback: LocationCallback

class MapsFragment : Fragment(), OnMapReadyCallback {

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)

        binding.map.onCreate(savedInstanceState)
        binding.map.onResume()
        firebaseAuth = FirebaseAuth.getInstance()
        binding.map.getMapAsync(this)
        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(activity!!)

        geocoder = Geocoder(requireActivity())
        searchView = binding.searchBar
        binding.myCurrentLocation.setOnClickListener{
            onMapReady(googleMap)
        }
        //searchLocation()
        
        // Support Fragment for Search
        //autoCompleteFrgment = (autoCompleteFrgment)
        //placesClient = Places.createClient(activity)


    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentMapsBinding.inflate(layoutInflater)
        return binding.root
    }


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val mapFragment = childFragmentManager.findFragmentById(R.id.map) as SupportMapFragment?
        mapFragment?.getMapAsync(this)
    }

    override fun onMapReady(map: GoogleMap) {
        checkPermission()
        googleMap = map
        googleMap.isMyLocationEnabled = true
        //googleMap.setOnMarkerClickListener(this)
        map.setOnMapClickListener(object : GoogleMap.OnMapClickListener{
            override fun onMapClick(latLng: LatLng) {
                markerOptions = MarkerOptions().position(latLng)
                map.clear()
                map.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng, 15f))
                map.addMarker(markerOptions)

            }
        })

        fusedLocationProviderClient.lastLocation.addOnSuccessListener {
            if (it != null) {
                currentLatLong = LatLng(it.latitude, it.longitude)
                markerOptions = MarkerOptions().position(currentLatLong)
                googleMap.clear()
                googleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(currentLatLong, 12f))
                googleMap.addMarker(markerOptions)

                geocoder = Geocoder(activity, Locale.getDefault())
                myadresses = geocoder.getFromLocation(it.latitude, it.longitude,1)



                searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener{
                    override fun onQueryTextSubmit(p0: String?): Boolean {
                        val locationName : String = searchView.query.toString()
                        try {

                            myadresses = geocoder.getFromLocationName("$locationName",1)
                            if(myadresses.size > 0){
                                Places.initialize(context,"AIzaSyDd6mCoEgv5Lq-gPvB1xTjw4E6vqtKT5-o")
                                val address1: Address = myadresses.get(0)
                                val hashmap: HashMap<String, Any> = HashMap()
                                hashmap["workerPlaces"] = address1.getAddressLine(0).toString()
                                Log.d(TAG, "onQueryTextSubmit: " + address1)


                                //update to db
                                val reference = FirebaseDatabase.getInstance().getReference("Workers")
                                reference.child(firebaseAuth.uid!!)
                                    .updateChildren(hashmap)
                                    .addOnSuccessListener {
                                       showMessage("saved location")
                                        Log.d(TAG, "savedLocation11111111111111111")

                                    }
                                    .addOnFailureListener {e->
                                           showMessage("error while saving location")
                                    }
                            }
                        } catch (e: Exception) {
                        }











                       // myadresses = listOf()
                       // if(location != null || location != ""){
                       //     try {
                       //         geocoder = Geocoder(requireActivity(), Locale.getDefault())
                       //         myadresses = geocoder.getFromLocationName(location, 1)
                       //     } catch (e: Exception){}
                       //     if(!myadresses.isEmpty()){
                       //         address = myadresses.get(0)
                       //     }
                       //     currentLatLong = LatLng(address.latitude, address.longitude)
                       //     googleMap.addMarker(MarkerOptions().position(currentLatLong))
                       //     googleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(currentLatLong, 12F))
                       //
                       // }
                        // val workPlaces = myadresses.get(0).getAddressLine(0).toString()
                        // val hashmap: HashMap<String, Any> = HashMap()
                        // hashmap["workerPlaces"] = workPlaces
                        //
                        //
                        // //update to db
                        // val reference = FirebaseDatabase.getInstance().getReference("Workers")
                        // reference.child(firebaseAuth.uid!!)
                        //     .updateChildren(hashmap)
                        //     .addOnSuccessListener {
                        //     }
                        //     .addOnFailureListener {e->
                        //
                        //     }


                        return false
                    }

                    override fun onQueryTextChange(p0: String?): Boolean {
                        return false
                    }

                })






            }
        }



        //map.setOnMarkerClickListener(this)

        map.uiSettings.isZoomControlsEnabled = true

       // map?.let {
       //     googleMap = it
       //     googleMap.setOnMarkerClickListener(this)
       //         googleMap.isMyLocationEnabled = true
       //         Places.initialize(requireActivity(), "AIzaSyAHvDn_yfH7Ofsd4reTtu6m5wl30tE8nh0")
       //         //googleMap.mapType = GoogleMap.MAP_TYPE_NORMAL
       //         googleMap.uiSettings.isZoomControlsEnabled = true
       //         fusedLocationProviderClient.lastLocation.addOnSuccessListener(activity!!) {
       //             if(it != null) {
       //                 currentLatLong = LatLng(it.latitude, it.longitude)
       //                 currentLat = it.latitude
       //                 currentLong = it.longitude
       //
       //                 // get Address from Lat and Long
       //                 //geocoder = Geocoder(requireActivity(), Locale.getDefault())
       //                 //myadresses = geocoder.getFromLocation(it.latitude, it.longitude,1)
       //                 //val address1: String = myadresses.get(0).getAddressLine(0)
       //
       //                 // Add SearchView on map
       //                 //val location: String = searchView.query.toString()
       //
       //                 // Add Marker on map
       //                 markerOptions = MarkerOptions()
       //                 markerOptions.position(currentLatLong)
       //                 //markerOptions.title("$address1")
       //                // googleMap.clear()
       //
       //
       //                 //placeMarkerOnMap(currentLatLong)
       //                 googleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(currentLatLong, 12f))
       //                 googleMap.addMarker(markerOptions)
       //                 googleMap.setOnMarkerClickListener(this)
       //
       //
       //
       //                 val hashmap: HashMap<String, Any> = HashMap()
       //                 hashmap["latitude"] = currentLat
       //                 hashmap["longtitude"] = currentLong
       //
       //
       //                 //update to db
       //                 val reference = FirebaseDatabase.getInstance().getReference("Workers")
       //                 reference.child(firebaseAuth.uid!!)
       //                     .updateChildren(hashmap)
       //                     .addOnSuccessListener {
       //                     }
       //                     .addOnFailureListener {e->
       //
       //                     }
       //             }
       //         }
       //
       // }
    }



    private fun checkPermission(){
        if(ContextCompat.checkSelfPermission(requireActivity(), Manifest.permission.ACCESS_FINE_LOCATION)!= PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(requireActivity(), arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 1)

            return
        }
    }


  //  private fun placeMarkerOnMap(currentLatLong: LatLng){
  //      val markerOptions = MarkerOptions().position(currentLatLong)
  //      markerOptions.title("$currentLatLong")
  //      googleMap.addMarker(markerOptions)
  //  }

    private fun searchLocation(){
        searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener{
            override fun onQueryTextSubmit(p0: String?): Boolean {
                val location : String = searchView.query.toString()
                myadresses = listOf()
                if(location != null || location != ""){
                    try {
                        geocoder = Geocoder(requireActivity(), Locale.getDefault())
                        myadresses = geocoder.getFromLocationName(location, 1)
                    } catch (e: Exception){}
                    if(!myadresses.isEmpty()){
                        address = myadresses.get(0)
                    }
                    currentLatLong = LatLng(address.latitude, address.longitude)
                    googleMap.addMarker(MarkerOptions().position(currentLatLong))
                    googleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(currentLatLong, 12F))

                }
               // val workPlaces = myadresses.get(0).getAddressLine(0).toString()
               // val hashmap: HashMap<String, Any> = HashMap()
               // hashmap["workerPlaces"] = workPlaces
               //
               //
               // //update to db
               // val reference = FirebaseDatabase.getInstance().getReference("Workers")
               // reference.child(firebaseAuth.uid!!)
               //     .updateChildren(hashmap)
               //     .addOnSuccessListener {
               //     }
               //     .addOnFailureListener {e->
               //
               //     }


                return false
            }

            override fun onQueryTextChange(p0: String?): Boolean {
                return false
            }

        })
    }

    private fun runEditProfileAgain(){
        startActivity(Intent(context,ProfileEditActivity::class.java))
    }

    private fun showMessage(string: String){
        Toast.makeText(context, string, Toast.LENGTH_SHORT).show()
    }



}