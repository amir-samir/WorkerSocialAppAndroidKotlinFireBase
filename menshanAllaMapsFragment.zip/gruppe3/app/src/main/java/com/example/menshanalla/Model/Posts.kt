package com.example.menshanalla.Model

data class Posts(
    val posts: PostsX?= null
)

data class PostsX(
    val description: String = "",
    val posting: List<Any>? = null
)